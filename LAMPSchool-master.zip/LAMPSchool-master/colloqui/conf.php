<?php

$db_server = "localhost";
$db_user = "massa";
$db_password = "dg032wf";
$db_name = "massa";

$con = mysqli_connect($db_server, $db_user, $db_password, $db_name) or die("Impossibile collegarsi al server");
?>
