--
-- Aggiornamento di LAMPSchool alla versione 2020.4
--

-- LASCIARE SEMPRE ALLA FINE
UPDATE tbl_parametri set valore='2020.4' where parametro='versioneprecedente';
-- LASCIARE SEMPRE ALLA FINE
