--
-- Aggiornamento di LAMPSchool alla versione 2019.1
--



-- LASCIARE SEMPRE ALLA FINE
UPDATE tbl_parametri set valore='2020' where parametro='versioneprecedente';
-- LASCIARE SEMPRE ALLA FINE
